/// @description Registers one faction definition.
function sc_faction_register(_faction, _data)
{
    var _factions = global.data.factions;

    if (!is_undefined(_factions[_faction]))
    {
        show_debug_message(
            "FACTION REGISTRATION ERROR - duplicate faction: "
            + string(_faction)
        );

        return false;
    }

    _factions[_faction] = _data;
    global.data.factions = _factions;

    return true;
}

/// @description Returns one registered faction palette.
function sc_faction_palette_get(_faction)
{
    var _factions = global.data.factions;

    if (_faction < 0 || _faction >= array_length(_factions))
    {
        show_debug_message(
            "FACTION PALETTE ERROR - invalid faction: "
            + string(_faction)
        );

        return undefined;
    }

    var _data = _factions[_faction];

    if (!is_struct(_data))
    {
        show_debug_message(
            "FACTION PALETTE ERROR - faction not registered: "
            + string(_faction)
        );

        return undefined;
    }

    return _data.palette;
}

/// @description Registers the Simulant faction and visual language.
function sc_faction_register_simulant()
{
    return sc_faction_register(Faction.SIMULANT, {
        identity: { name: "Simulant" },

        palette: {
            void: make_colour_rgb(4, 2, 8),
            hull_dark: make_colour_rgb(13, 10, 20),
            hull_mid: make_colour_rgb(28, 23, 40),
            hull_light: make_colour_rgb(56, 47, 76),
            metal: make_colour_rgb(124, 112, 150),

            outline: make_colour_rgb(102, 86, 138),
            accent: make_colour_rgb(132, 66, 255),
            energy: make_colour_rgb(184, 94, 255),
            core: make_colour_rgb(243, 224, 255),
            glow: make_colour_rgb(106, 42, 224)
        }
    });
}